nokey_apis = {
    "country_info": ["RestCountries"],
    "finance": ["Wallstreet Bets"],
    "geolocation": ["IP API", "Zippopotomus"],
    "spaceflight": ["Spaceflight News"],
    "education": ["University Names and Domains"],
    "food": ["Fruityvice"],
    "random": ["RandomUserGenerator"],
    "jokes": ["JokeAPI"],
    "animals": ["DogAPI"],
    "science": ["Nobel Prize API"],
    "weather": ["National Weather Service API"],
    "developer_tools": ["URL Shortener"],
    "inspiration": ["Dictum"],
    "language": ["Free Dictionary"],
    "games": ["Free To Game"]
}
